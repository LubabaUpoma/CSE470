<p>Chatroom is a basic chat application in php. <br>
It is a pull application ie. refreshes users online and chat messages after certain fixed interval.</p>

<h3>Features:</h3> 
<ul>
<li>Chatbox color changes if chatbox is minimized during a new chat message.</li>
<li>Search users online.</li>
<li>Smileys used.</li>
<li>Chat sound when user is not on chat window.</li>
</ul>

<h3>Scope:</h3>
<ul>
<li>Supported in all major browsers except IE (design problem).</li>
</ul>
