<?php
define(DOC_DIR,dirname(__FILE__));
$db_file = DOC_DIR."/config.php";
?>
